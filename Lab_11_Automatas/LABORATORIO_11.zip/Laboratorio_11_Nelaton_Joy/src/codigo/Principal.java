/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codigo;

import java.io.File;

/**
 *
 * @author LAI1-21
 */







public class Principal {
              
            
    public static void main(String[] args) {
       String ruta = "C:/Users/LAI1-21/Desktop/LABORATORIO_11/Laboratorio_11_Nelaton_Joy/src/codigo/Lexer.flex";
        generarLexer(ruta);
    }
//Crear la clase public stactic void 
    public static void generarLexer(String ruta){ 
        File archivo = new File(ruta);    // al escribir new preciona las teclas alt +Enter y te aparecera el archivo file  importando la librería al codigo
        JFlex.Main.generate(archivo);
    }

            
            
            
            
            
}
